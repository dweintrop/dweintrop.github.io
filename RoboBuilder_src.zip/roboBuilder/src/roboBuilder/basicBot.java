package roboBuilder;

import robocode.*;
import java.util.*;
import java.awt.Color;

public class basicBot extends Robot {public void onScannedRobot(ScannedRobotEvent e) {fire(1);
}
public void run() {while(true){ahead(100);
turnLeft(360);
back(100);
}}
}

