package javaExporter;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.util.*;

import org.apache.tools.ant.Project;
import org.apache.tools.ant.ProjectHelper;

import workspace.Workspace;
import codeblocks.Block;
import codeblocks.BlockConnector;

public class JavaCreator {

	private static Map<Long, Block> blockMap;

	public static void deploy(Workspace workspace, String robotName) {
		generateJavaFile(workspace, robotName);
		compileCopyLaunch(0, robotName);
	}
	
	public static void deploy(Workspace workspace, String robotName, int battleNum) {
		generateJavaFile(workspace, robotName);
		compileCopyLaunch(battleNum, robotName);
	}

	public static void generateJavaFile(Workspace workspace, String robotName) {

		StringBuilder javaclass = getJavaBoilerPlate(robotName);
		blockMap = new HashMap<Long, Block>();

		// build map of blocks
		for (Block block : workspace.getBlocks()) {
			blockMap.put(block.getBlockID(), block);
		}

		// for each top-level block - build function
		for (Block block : workspace.getBlocks()) {
			if ("true".equals(block.getProperty("isFunction"))) {
				javaclass.append(generateFunction(block));
			}
		}

		javaclass.append("}\n\n");
		packageUpFile(robotName, javaclass.toString());
	}

	private static void packageUpFile(String robotName, String contents) {
		System.out.println(contents);
		try {
			// Create file
			File robotFile = new File("myRobots", robotName + ".java");
			FileWriter fstream = new FileWriter(robotFile);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write(contents);
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}

	private static String generateFunction(Block block) {
		// if number - return its label (value)
		if ("number".equals(block.getGenusName())) {
			return block.getBlockLabel();
		}

		// if data block - return data value
		if (block.isDataBlock()) {
			return block.getProperty("java-start");
		}

		// if command block (do something block - movement, if/else, main functions...) pass control to command builder
		if (block.isCommandBlock()) {
			return handleCommandBlock(block);
		}

		// if function block (something inside ()'s in java like ands, or, sums,
		// equals...) pass control to function builder
		if (block.isFunctionBlock()) {
			return handleFunctionBlock(block);
		}
		
		return "failed to handle: " + block.toString();
	}

	private static String handleCommandBlock(Block block) {
		StringBuilder sb = new StringBuilder(block.getProperty("java-start"));

		// look for test conditions
		for (BlockConnector bc : block.getSockets()) {
			if (blockMap.get(bc.getBlockID()).isDataBlock() || blockMap.get(bc.getBlockID()).isFunctionBlock()) {
				sb.append(generateFunction(blockMap.get(bc.getBlockID())));
			}
		}
		if (null != block.getProperty("java-middle")) {
			sb.append(block.getProperty("java-middle")).append("\n").toString();
		}

		// special logic for if-then-else (because it has 2 command blocks)
		if ("ifelse".equals(block.getBlockLabel())) {
			for (BlockConnector bc : block.getSockets()) {
				if ("then".equals(bc.getLabel())) {
					sb.append(generateFunction(blockMap.get(bc.getBlockID())));
					break;
				}
			}			
			sb.append(block.getProperty("java-middle2"));
			for (BlockConnector bc : block.getSockets()) {
				if ("else".equals(bc.getLabel())) {
					sb.append(generateFunction(blockMap.get(bc.getBlockID())));
					break;
				}
			}			
			
		} else {
			// non-test condition sockets
			for (BlockConnector bc : block.getSockets()) {
				if (blockMap.get(bc.getBlockID()).isCommandBlock()) {
					sb.append(generateFunction(blockMap.get(bc.getBlockID())));
				}
			}
		}
		
		if (null != block.getProperty("java-end")) {
			sb.append(block.getProperty("java-end")).append("\n").toString();
		}

		// subsequent blocks
		if (!Block.NULL.equals(block.getAfterBlockID())) {
			sb.append(generateFunction(blockMap.get(block.getAfterBlockID())));
		}

		return sb.toString();
	}

	private static String handleFunctionBlock(Block block) {
		StringBuilder sb = new StringBuilder(block.getProperty("java-start"));

		if (block.getNumSockets() > 0) {
			BlockConnector bc = block.getSocketAt(0);
			sb.append(generateFunction(blockMap.get(bc.getBlockID())));

			if (block.getNumSockets() > 1) {
				if (null != block.getProperty("java-middle")) {
					sb.append(block.getProperty("java-middle")).append("\n").toString();
				}
				bc = block.getSocketAt(1);
				sb.append(generateFunction(blockMap.get(bc.getBlockID())));
			}
		}

		if (null != block.getProperty("java-end")) {
			sb.append(block.getProperty("java-end")).append("\n").toString();
		}

		return sb.toString();
	}

	private static StringBuilder getJavaBoilerPlate(String robotName) {
		StringBuilder sb = new StringBuilder();
		sb.append("package roboBuilder;\n\n");
		
		sb.append("import robocode.*;\n");
		sb.append("import robocode.util.*;\n");
		sb.append("import java.util.*;\n");
		sb.append("import java.awt.Color;\n");
		sb.append("\n");
		sb.append("public class " + robotName + " extends Robot {");
		return sb;
	}

	private static void compileCopyLaunch(int battleNum, String robotName) {
		File buildFile = new File("config/launch-robocode.xml");
		Project p = new Project();
		p.setUserProperty("ant.file", buildFile.getAbsolutePath());
		p.init();
		ProjectHelper helper = ProjectHelper.getProjectHelper();
		p.addReference("ant.projectHelper", helper);
		helper.parse(p, buildFile);
		if (battleNum > 0) {
			makeBattleFile(battleNum, robotName);
			p.executeTarget("launch-battle");
		} else {
			p.executeTarget("launch");
		}
	}

	private static void makeBattleFile(int battleNum, String robotName) {
		StringBuilder battle = new StringBuilder();
		battle.append("#Battle Properties\n");
		battle.append("robocode.battleField.width=800\n");
		battle.append("robocode.battleField.height=600\n");
		battle.append("robocode.battle.numRounds=3\n");
		battle.append("robocode.battle.gunCoolingRate=0.1\n");
		battle.append("robocode.battle.rules.inactivityTime=450\n");
		
		switch(battleNum) {
		case 1:
			battle.append("robocode.battle.selectedRobots=roboBuilder.doNothingBot*,");
			break;
		case 2:
			battle.append("robocode.battle.selectedRobots=roboBuilder.moveWhenHitBot*,");
			break;
		case 3:
			battle.append("robocode.battle.selectedRobots=roboBuilder.spinAndShootBot*,");
			break;
		case 4:
			battle.append("robocode.battle.selectedRobots=roboBuilder.spinShootAndAvoidBot*,");
			break;
		case 5:
			battle.append("robocode.battle.selectedRobots=roboBuilder.forwardBackwardBot*,");
			break;
		case 6:
			battle.append("robocode.battle.selectedRobots=roboBuilder.spinGunAndShootBigBot*,");
			break;
		case 7:
			battle.append("robocode.battle.selectedRobots=roboBuilder.steadyFireBot*,");
			break;
		default:
			battle.append("robocode.battle.selectedRobots=roboBuilder.doNothingBot*,");
			break;
		}
		battle.append("roboBuilder.").append(robotName).append("*\n");
		
		System.out.println(battle.toString());
		try {
			// Create file
			File battleFile = new File("myRobots", "roboBuilder.battle");
			FileWriter fstream = new FileWriter(battleFile);
			BufferedWriter out = new BufferedWriter(fstream);
			out.write(battle.toString());
			out.close();
		} catch (Exception e) {// Catch exception if any
			System.err.println("Error: " + e.getMessage());
		}
	}
	
}
