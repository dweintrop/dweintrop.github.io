package codeblockutil;

public interface ExplorerEvent {
	public int getEventType();
	
	public Explorer getSource();
}
