package codeblockutil;

import java.awt.Color;

public final class CGraphite {
	private CGraphite(){}
	public static Color blue = new Color(77,109,243);
	public static final Color gray = new Color(180,180,180);
	public static final Color lightgray = Color.lightGray;
	public static final Color milky = new Color(0,0,0,100);
	public static final Color white = new Color(240,240,240);
	//200-500 isused
	private static final long serialVersionUID = 328149080430L;
}
