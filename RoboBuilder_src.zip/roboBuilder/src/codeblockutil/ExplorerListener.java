package codeblockutil;


public interface ExplorerListener {
	
	public void explorerEventOccurred(ExplorerEvent event);

}
